# Island Tours - cPanel Deployment Instructions 
 
## 🚀 Quick Deployment Steps 
 
### 1. Upload Files 
- Extract this ZIP package to your cPanel public_html directory 
- Or upload to a subdirectory if not using main domain 
 
### 2. Configure Environment 
- Edit the .env file with your actual database credentials 
- Update APP_URL to your actual domain 
- Generate APP_KEY by running: `php artisan key:generate` 
 
### 3. Install Dependencies 
Run via SSH or cPanel Terminal: 
```bash 
composer install --no-dev --optimize-autoloader 
php artisan key:generate 
php artisan migrate --force 
php artisan config:cache 
php artisan route:cache 
php artisan view:cache 
php artisan storage:link 
``` 
 
### 4. Set Permissions 
- storage/ directory: 755 
- storage/logs/: 755 
- bootstrap/cache/: 755 
 
### 5. Domain Configuration 
- Point your domain to the 'public' folder 
- Or move contents of 'public' to root if using main domain 
