// Laravel Mix Bootstrap
require('./bootstrap');

// Add these lines for jQuery
import $ from 'jquery';
window.$ = window.jQuery = $;
