<div class="p-6">
    <div class="mb-4 flex justify-end">
        <a href="/booking" class="btn btn-primary">+ New Booking</a>
    </div>
    <h2 class="text-xl font-bold mb-4">My Bookings</h2>
    <table class="w-full border">
        <thead>
            <tr>
                <th class="p-2 border">Reference</th>
                <th class="p-2 border">Date</th>
                <th class="p-2 border">Status</th>
                <th class="p-2 border">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="p-2 border"><?php echo e($booking->id); ?></td>
                <td class="p-2 border"><?php echo e(\Illuminate\Support\Carbon::parse($booking->date)->format('M d, Y')); ?></td>
                <td class="p-2 border"><?php echo e(ucfirst($booking->status)); ?></td>
                <td class="p-2 border">
                    <a href="<?php echo e(route('user.booking.show', $booking->id)); ?>" class="text-blue-600">View</a>
                    <?php if($booking->status === 'approved'): ?>
                        <a href="<?php echo e(route('user.booking.pay', $booking->id)); ?>" class="text-green-600 ml-2">Pay Now</a>
                    <?php endif; ?>
                    <?php if($booking->status === 'returned'): ?>
                        <a href="<?php echo e(route('user.booking.edit', $booking->id)); ?>" class="text-yellow-600 ml-2">Edit</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" class="p-2 text-center">No bookings found.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="mt-4">
        <?php echo e($bookings->links()); ?>

    </div>
</div><?php /**PATH C:\Users\Darylje\island-tours\resources\views\livewire\user-bookings.blade.php ENDPATH**/ ?>