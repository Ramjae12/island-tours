<div>
    <h2>Date Management</h2>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success mb-2">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form wire:submit.prevent="<?php echo e($isEditing ? 'update' : 'store'); ?>" class="mb-4">
        <input type="date" wire:model.defer="date" required>
        <input type="text" wire:model.defer="label" placeholder="Label (optional)">
        <label>
            <input type="checkbox" wire:model.defer="active">
            Active
        </label>
        <button type="submit" class="btn btn-primary">
            <?php echo e($isEditing ? 'Update' : 'Add'); ?> Date
        </button>
        <?php if($isEditing): ?>
            <button type="button" wire:click="resetForm" class="btn btn-secondary">Cancel</button>
        <?php endif; ?>
    </form>

    <table class="table-auto w-full">
        <thead>
            <tr>
                <th>Date</th>
                <th>Label</th>
                <th>Active?</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($d->date); ?></td>
                    <td><?php echo e($d->label); ?></td>
                    <td>
                        <?php if($d->active): ?>
                            <span class="text-green-600 font-bold">Yes</span>
                        <?php else: ?>
                            <span class="text-gray-500">No</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <button wire:click="edit(<?php echo e($d->id); ?>)" class="btn btn-sm btn-info">Edit</button>
                        <button wire:click="delete(<?php echo e($d->id); ?>)" class="btn btn-sm btn-danger"
                                onclick="return confirm('Are you sure?')">Delete</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">No dates found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="mt-4">
        <?php echo e($dates->links()); ?>

    </div>
</div><?php /**PATH C:\Users\Darylje\island-tours\resources\views\livewire\admin\dates.blade.php ENDPATH**/ ?>