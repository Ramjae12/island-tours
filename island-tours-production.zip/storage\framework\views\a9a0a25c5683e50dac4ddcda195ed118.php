<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Island Tours</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <div class="admin-container">
        <div class="sidebar">
            <div class="logo">
                <h2>Island Tours</h2>
                <p>Admin Panel</p>
            </div>
            <ul class="sidebar-menu">
                <li>
                    <?php if(Auth::check() && Auth::user()->hasRole('admin')): ?>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.bookings')); ?>">
                        <i class="fas fa-calendar-check"></i> Bookings
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.users')); ?>">
                        <i class="fas fa-users"></i> Users
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.packages')); ?>">
                        <i class="fas fa-box-open"></i> Packages
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.available-dates')); ?>">
                        <i class="fas fa-calendar-alt"></i> Date Management
                    </a>
                </li>
            </ul>
            <div style="position: absolute; bottom: 32px; left: 0; width: 100%; text-align: center;">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" id="adminLogout" style="background:none;border:none;color:inherit;cursor:pointer; font-size: 1.1em; padding: 12px 0; width: 100%;">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </button>
                </form>
            </div>
        </div>
        <div class="main-content">
            <div class="top-bar" style="display: flex; align-items: center; justify-content: flex-end;">
                <div style="display: flex; align-items: center; gap: 24px; margin-left: auto;">
                    <?php if (isset($component)) { $__componentOriginal6256a41827a60bb4a6fb9d463f328406 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6256a41827a60bb4a6fb9d463f328406 = $attributes; } ?>
<?php $component = App\View\Components\NotificationBell::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('notification-bell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\NotificationBell::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6256a41827a60bb4a6fb9d463f328406)): ?>
<?php $attributes = $__attributesOriginal6256a41827a60bb4a6fb9d463f328406; ?>
<?php unset($__attributesOriginal6256a41827a60bb4a6fb9d463f328406); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6256a41827a60bb4a6fb9d463f328406)): ?>
<?php $component = $__componentOriginal6256a41827a60bb4a6fb9d463f328406; ?>
<?php unset($__componentOriginal6256a41827a60bb4a6fb9d463f328406); ?>
<?php endif; ?>
                    <div class="admin-profile">
                        <span><?php echo e(Auth::user()->name ?? 'Admin User'); ?></span>
                        <img src="<?php echo e(asset('image/user.png')); ?>" alt="Admin">
                    </div>
                </div>
            </div>
            <div class="content">
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\Darylje\island-tours\resources\views\layouts\admin.blade.php ENDPATH**/ ?>