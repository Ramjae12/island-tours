<div>
    <div class="mb-4 flex justify-end">
        <a href="/user/bookings" class="btn btn-secondary">My Bookings</a>
    </div>

    <?php if(Auth::check()): ?>
        <div style="color:green;">User is authenticated: <?php echo e(Auth::user()->email); ?></div>
    <?php else: ?>
        <div style="color:red;">User is NOT authenticated</div>
    <?php endif; ?>

    <div class="booking-form-bg">
        <!-- Progress Bar Section -->
        <div class="progress-bg">
            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress" style="width: <?php echo e(($step-1)/3*100); ?>%"></div>
                    <div class="step <?php echo e($step >= 1 ? 'active' : ''); ?>">1</div>
                    <div class="step <?php echo e($step >= 2 ? 'active' : ''); ?>">2</div>
                    <div class="step <?php echo e($step >= 3 ? 'active' : ''); ?>">3</div>
                    <div class="step <?php echo e($step == 4 ? 'active' : ''); ?>">4</div>
                </div>
                <div class="step-labels">
                    <div class="step-label <?php echo e($step == 1 ? 'active' : ''); ?>">Select Date</div>
                    <div class="step-label <?php echo e($step == 2 ? 'active' : ''); ?>">Choose Package</div>
                    <div class="step-label <?php echo e($step == 3 ? 'active' : ''); ?>">Personal Info</div>
                    <div class="step-label <?php echo e($step == 4 ? 'active' : ''); ?>">Confirmation</div>
                </div>
            </div>
        </div>

        <!-- Main Booking Card -->
        <div class="booking-form-section">
            <div class="container">
                <h2>Book Your Tour</h2>

                
                <?php if($step == 1): ?>
                <div class="form-step active">
                    <h3>Select Your Tour Date</h3>
                    <div class="calendar-container">
                        <div class="calendar-header">
                            <button type="button" wire:click="$set('calendarMonth', $calendarMonth - 1)" class="btn btn-link"><i class="fas fa-chevron-left"></i></button>
                            <h4><?php echo e(\Carbon\Carbon::create($calendarYear, $calendarMonth)->format('F Y')); ?></h4>
                            <button type="button" wire:click="$set('calendarMonth', $calendarMonth + 1)" class="btn btn-link"><i class="fas fa-chevron-right"></i></button>
                        </div>
                        <div class="weekdays">
                            <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
                        </div>
                        <div class="days">
                            <?php
                                $firstDay = \Carbon\Carbon::create($calendarYear, $calendarMonth, 1);
                                $daysInMonth = $firstDay->daysInMonth;
                                $startDay = $firstDay->dayOfWeek;
                            ?>
                            <?php for($i = 0; $i < $startDay; $i++): ?>
                                <div class="calendar-day empty"></div>
                            <?php endfor; ?>
                            <?php for($day = 1; $day <= $daysInMonth; $day++): ?>
                                <?php
                                    $dateStr = \Carbon\Carbon::create($calendarYear, $calendarMonth, $day)->toDateString();
                                    $setting = $dateSettings[$dateStr] ?? null;
                                    $isClosed = $setting && $setting['is_closed'];
                                    $isFull = $setting && $setting['current_bookings'] >= $setting['max_slots'];
                                ?>
                                <div class="calendar-day
                                    <?php echo e($isClosed ? 'disabled' : ''); ?>

                                    <?php echo e($isFull ? 'full' : ''); ?>

                                    <?php echo e($selectedDate === $dateStr ? 'selected' : ''); ?>"
                                    <?php if(!$isClosed && !$isFull): ?>
                                        wire:click="selectDate('<?php echo e($dateStr); ?>')"
                                        style="cursor:pointer; display: flex; flex-direction: column; align-items: center; justify-content: flex-start; height: 48px; position: relative;"
                                    <?php else: ?>
                                        style="cursor:not-allowed; display: flex; flex-direction: column; align-items: center; justify-content: flex-start; height: 48px; position: relative;"
                                    <?php endif; ?>
                                >
                                    <span style="margin-bottom:2px; display: block;"><?php echo e($day); ?></span>
                                    <?php if($setting && !$isClosed && !$isFull): ?>
                                        <span class="slot-info" style="font-size:0.8em;color:#2563eb;font-weight:bold;line-height:1; margin-top:0; position: absolute; top: 22px; left: 50%; transform: translateX(-50%);"><?php echo e($setting['available_slots']); ?> slot<?php echo e($setting['available_slots'] == 1 ? '' : 's'); ?></span>
                                    <?php elseif($setting && $isClosed): ?>
                                        <span class="slot-info" style="font-size:0.8em;color:#dc2626;font-weight:bold;line-height:1; margin-top:0; position: absolute; top: 22px; left: 50%; transform: translateX(-50%);">Closed</span>
                                    <?php elseif($setting && $isFull): ?>
                                        <span class="slot-info" style="font-size:0.8em;color:#ca8a04;font-weight:bold;line-height:1; margin-top:0; position: absolute; top: 22px; left: 50%; transform: translateX(-50%);">Full</span>
                                    <?php endif; ?>
                                </div>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <div class="selected-date-display">
                        <p>Selected Date: <span><?php echo e($selectedDate ?? 'None'); ?></span></p>
                        <?php $__errorArgs = ['selectedDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-buttons">
                        <button type="button" class="btn btn-primary btn-next next-btn" wire:click="nextStep" <?php if(!$selectedDate): ?> disabled <?php endif; ?>>Next</button>
                    </div>
                </div>
                <?php endif; ?>

                
                <?php if($step == 2): ?>
                <div class="form-step active">
                    <h3>Choose Your Package</h3>
                    <div class="rates-container">
                        <?php $__currentLoopData = $packages->groupBy('type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <h4><?php echo e(strtoupper(str_replace('_', ' ', $type))); ?></h4>
                                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="rate-item">
                                        <div class="rate-info">
                                            <span class="rate-name"><?php echo e($pkg->name); ?></span>
                                            <span class="rate-price">
                                                ₱<?php echo e(number_format($pkg->discount_price ?? $pkg->price, 2)); ?>

                                                <?php echo e($pkg->price_label ?? 'per person/day'); ?>

                                                <?php if($pkg->discount_price): ?>
                                                    <span class="original-price">₱<?php echo e(number_format($pkg->price, 2)); ?></span>
                                                <?php endif; ?>
                                            </span>
                                            <?php if($pkg->requires_id): ?>
                                                <span class="badge-id">ID Required</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="quantity-selector">
                                            <button type="button" class="quantity-btn" wire:click="decreaseQuantity(<?php echo e($pkg->id); ?>)">-</button>
                                            <span class="quantity-value"><?php echo e($packageQuantities[$pkg->id] ?? 0); ?></span>
                                            <button type="button" class="quantity-btn" wire:click="increaseQuantity(<?php echo e($pkg->id); ?>)">+</button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="booking-summary">
                        <h4>Booking Summary</h4>
                        <div>
                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(($packageQuantities[$pkg->id] ?? 0) > 0): ?>
                                    <div><?php echo e($pkg->name); ?>: <?php echo e($packageQuantities[$pkg->id]); ?> × ₱<?php echo e(number_format($pkg->discount_price ?? $pkg->price, 2)); ?> = ₱<?php echo e(number_format($packageQuantities[$pkg->id] * ($pkg->discount_price ?? $pkg->price), 2)); ?></div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="total-amount">
                            <p>Total Amount: <span>₱<?php echo e(number_format($totalAmount, 2)); ?></span></p>
                        </div>
                    </div>
                    <?php $__errorArgs = ['packageQuantities'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-buttons">
                        <button type="button" class="btn btn-secondary prev-btn" wire:click="prevStep">Previous</button>
                        <button type="button" class="btn btn-primary btn-next next-btn" wire:click="nextStep" <?php if($totalAmount <= 0): ?> disabled <?php endif; ?>>Next</button>
                    </div>
                </div>
                <?php endif; ?>

                
                <?php if($step == 3): ?>
                <div class="form-step active">
                    <h3>Personal Information</h3>
                    <div class="form-group mb-3">
                        <label for="fullName" class="form-label">Full Name</label>
                        <input type="text" wire:model="full_name" id="fullName" required class="form-control">
                        <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" wire:model="email" id="email" required class="form-control">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mb-3">
                        <label for="phone" class="form-label">Phone Number</label>
                        <input type="tel" wire:model="phone" id="phone" required class="form-control">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mb-3">
                        <label for="address" class="form-label">Address</label>
                        <textarea wire:model="address" id="address" required class="form-control"></textarea>
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="id-upload-section">
                        <h4>Upload Valid IDs</h4>
                        <p>Please upload a valid ID for each person in your group (required for verification)</p>
                        <div class="id-uploads">
                            <?php
                                $totalIds = 0;
                                foreach($packages as $pkg) {
                                    if($pkg->requires_id && ($packageQuantities[$pkg->id] ?? 0) > 0) {
                                        $totalIds += $packageQuantities[$pkg->id];
                                    }
                                }
                            ?>
                            <?php for($i = 0; $i < $totalIds; $i++): ?>
                                <div class="file-upload-row mb-2">
                                    <label class="form-label">ID for Person <?php echo e($i + 1); ?>:</label>
                                    <input type="file" wire:model="idUploads.<?php echo e($i); ?>" accept="image/jpeg,image/png,application/pdf" required class="form-control">
                                    <?php $__errorArgs = ['idUploads.' . $i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endfor; ?>
                            <?php if($totalIds == 0): ?>
                                <p>No ID uploads required for selected packages.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-buttons">
                        <button type="button" class="btn btn-secondary prev-btn" wire:click="prevStep">Previous</button>
                        <button type="button" class="btn btn-primary btn-next next-btn" wire:click="submit">Submit</button>
                    </div>
                </div>
                <?php endif; ?>

                
                <?php if($step == 4): ?>
                <div class="form-step active">
                    <h3>Booking Confirmation</h3>
                    <div class="confirmation-message">
                        <div class="confirmation-icon"><i class="fas fa-check-circle"></i></div>
                        <h4>Thank You for Your Booking!</h4>
                        <p>Your booking has been submitted and is pending approval from our administrators.</p>
                        <p>Booking Reference: <span><?php echo e($bookingReference); ?></span></p>
                        <p>Please wait for an email confirmation with payment instructions once your booking is approved.</p>
                    </div>
                    <div class="form-buttons">
                        <a href="<?php echo e(route('user.bookings')); ?>" class="btn btn-primary">Return to My Bookings</a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Darylje\island-tours\resources\views\livewire\booking-form.blade.php ENDPATH**/ ?>