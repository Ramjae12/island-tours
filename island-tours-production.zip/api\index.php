<?php

// Vercel PHP Runtime Entry Point
require __DIR__ . '/../public/index.php';
