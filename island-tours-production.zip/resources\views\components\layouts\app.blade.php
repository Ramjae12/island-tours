{{-- This file is intentionally left blank to remove the legacy login form. --}}
