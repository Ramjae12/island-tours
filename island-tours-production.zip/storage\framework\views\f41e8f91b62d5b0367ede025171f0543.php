<!-- Dashboard Section -->
<div class="content-section active" id="dashboard-section">
    <h2>Dashboard</h2>
    <div class="stats-cards">
        <div class="stat-card">
            <div class="stat-value"><?php echo e($newBookings ?? 0); ?></div>
            <div class="stat-label">New Bookings</div>
            <div class="stat-icon"><i class="fas fa-calendar-plus"></i></div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo e($pendingApproval ?? 0); ?></div>
            <div class="stat-label">Pending Approval</div>
            <div class="stat-icon"><i class="fas fa-clock"></i></div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo e($registeredUsers ?? 0); ?></div>
            <div class="stat-label">Registered Users</div>
            <div class="stat-icon"><i class="fas fa-user-plus"></i></div>
        </div>
        <div class="stat-card">
            <div class="stat-value">₱<?php echo e(number_format($revenueThisMonth ?? 0, 2)); ?></div>
            <div class="stat-label">Revenue This Month</div>
            <div class="stat-icon"><i class="fas fa-money-bill-wave"></i></div>
        </div>
    </div>
    <div class="recent-section">
        <h3>Recent Bookings</h3>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Customer</th>
                        <th>Package</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentBookings ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($booking->id); ?></td>
                            <td><?php echo e($booking->customer_name); ?></td>
                            <td><?php echo e($booking->package_name); ?></td>
                            <td><?php echo e($booking->date); ?></td>
                            <td>₱<?php echo e(number_format($booking->total_amount, 2)); ?></td>
                            <td>
                                <span class="status <?php echo e(strtolower($booking->status)); ?>">
                                    <?php echo e(ucfirst($booking->status)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.bookings')); ?>" class="btn-review">Review</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7">No recent bookings.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH C:\Users\Darylje\island-tours\resources\views\livewire\admin\dashboard.blade.php ENDPATH**/ ?>