<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title ?? config('app.name', 'Island Tours')); ?></title>
    
    <!-- Bootstrap CSS (provides base styling) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Your custom booking CSS file -->
    <link rel="stylesheet" href="<?php echo e(asset('css/booking-form.css')); ?>">
    
    <!-- Vite assets -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="/">Island Tours</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/">Home</a>
                    </li>
                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item ms-2">
                            <?php if (isset($component)) { $__componentOriginal6256a41827a60bb4a6fb9d463f328406 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6256a41827a60bb4a6fb9d463f328406 = $attributes; } ?>
<?php $component = App\View\Components\NotificationBell::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('notification-bell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\NotificationBell::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6256a41827a60bb4a6fb9d463f328406)): ?>
<?php $attributes = $__attributesOriginal6256a41827a60bb4a6fb9d463f328406; ?>
<?php unset($__attributesOriginal6256a41827a60bb4a6fb9d463f328406); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6256a41827a60bb4a6fb9d463f328406)): ?>
<?php $component = $__componentOriginal6256a41827a60bb4a6fb9d463f328406; ?>
<?php unset($__componentOriginal6256a41827a60bb4a6fb9d463f328406); ?>
<?php endif; ?>
                        </li>
                        <li class="nav-item">
                            <div style="color: #0a0; font-weight: bold;">User: <?php echo e(Auth::user()->email); ?> | Roles: <?php echo e(implode(',', Auth::user()->getRoleNames()->toArray())); ?> | Notifications: <?php echo e(Auth::user()->notifications()->count()); ?></div>
                        </li>
                        <?php if(Auth::user()->hasRole('admin')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="nav-link btn btn-link">Logout</button>
                            </form>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php echo e($slot); ?>

    </div>

    <footer class="mt-5 py-3 bg-dark text-white text-center">
        <div class="container">
            <p class="mb-0">&copy; <?php echo e(date('Y')); ?> Island Tours. All rights reserved.</p>
        </div>
    </footer>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH C:\Users\Darylje\island-tours\resources\views\layouts\app.blade.php ENDPATH**/ ?>